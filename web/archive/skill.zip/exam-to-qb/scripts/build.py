import argparse,csv,io,pathlib,sys
p=argparse.ArgumentParser(); p.add_argument('--tsv',required=True); p.add_argument('--out',required=True); p.add_argument('--header',default=str(pathlib.Path(__file__).resolve().parents[1]/'assets/header.csv')); g=p.add_mutually_exclusive_group(); g.add_argument('--category',default=''); g.add_argument('--category-file'); p.add_argument('--big5',action='store_true'); p.add_argument('--big5-out'); a=p.parse_args()
rows=[line.split('\t') for line in pathlib.Path(a.tsv).read_text(encoding='utf-8-sig').splitlines() if line.strip()]
cats=pathlib.Path(a.category_file).read_text(encoding='utf-8-sig').splitlines() if a.category_file else [a.category]*len(rows)
if len(cats)!=len(rows) or not rows: sys.exit('Invalid category count or empty input')
header=list(csv.reader(io.StringIO(pathlib.Path(a.header).read_text(encoding='utf-8-sig')))); assert len(header)==2 and all(len(r)==27 for r in header)
buf=io.StringIO(newline=''); w=csv.writer(buf,lineterminator='\r\n'); w.writerows(header)
for i,(r,cat) in enumerate(zip(rows,cats),1):
    if not 5<=len(r)<=25 or r[0] not in '12345' or len(r[0])!=1 or not r[1] or r[4] not in ('1','2','3'): sys.exit(f'Invalid row {i}')
    t,q,ans,ex,d,*opts=r
    if t=='1' and ans not in ('1','2'): sys.exit(f'Invalid true/false {i}')
    if t in ('2','3'):
        aa=ans.split(',')
        if (t=='2' and len(aa)!=1) or (t=='3' and len(aa)<2) or len(set(aa))!=len(aa) or any(not x.isdigit() or not 1<=int(x)<=len(opts) or not opts[int(x)-1] for x in aa): sys.exit(f'Invalid choice answer {i}')
    if t=='4' and (ans or '[*' not in q or '*]' not in q or len(opts)<2 or any(x not in ('1','2') for x in opts[:2])): sys.exit(f'Invalid fill-in {i}')
    if t=='5' and not ans: sys.exit(f'Missing essay answer {i}')
    w.writerow([v.replace('\\n','\r\n') for v in ['',cat]+r+['']*(25-len(r))])
content=buf.getvalue(); out=pathlib.Path(a.out); out.write_bytes(content.encode('utf-8')); print(f'OK rows={len(rows)} BOM=False')
if a.big5 or a.big5_out:
    s=content.translate(str.maketrans({'\u2265':'\u2267','\u2264':'\u2266','\u30fb':'\u2027'})); bad=[]
    for ch in sorted(set(s)):
        try: ch.encode('cp950')
        except UnicodeEncodeError: bad.append(f'U+{ord(ch):04X}')
    target=pathlib.Path(a.big5_out) if a.big5_out else out.with_name(out.stem+'_big5'+out.suffix); target.write_bytes(s.encode('cp950',errors='replace')); print('WARN UNMAPPABLE '+', '.join(bad) if bad else 'OK CP950 after remapping')
