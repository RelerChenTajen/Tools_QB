import argparse,pathlib,zipfile,xml.etree.ElementTree as E
p=argparse.ArgumentParser(); p.add_argument('input'); p.add_argument('-o','--output'); a=p.parse_args(); f=pathlib.Path(a.input)
if f.suffix.lower()=='.docx':
    with zipfile.ZipFile(f) as z: root=E.fromstring(z.read('word/document.xml'))
    ns='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    s='\n'.join(''.join(t.text or '' for t in para.iter(ns+'t')) for para in root.iter(ns+'p'))
elif f.suffix.lower() in ('.txt','.md','.csv','.tsv'): s=f.read_text(encoding='utf-8-sig')
else: p.error('Use host PDF reader or convert legacy DOC to DOCX')
if a.output: pathlib.Path(a.output).write_bytes(s.encode('utf-8'))
else: print(s)
